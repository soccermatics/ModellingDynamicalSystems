"""
ARMA models
===========


"""
